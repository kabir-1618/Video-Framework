package com.oreilly.entities;

public interface Team {
    String getName();
}
